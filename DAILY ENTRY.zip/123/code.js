document.addEventListener('DOMContentLoaded', function() {
    // Get form and buttons
    const form = document.getElementById('dataForm');
    const addSaveBtn = document.getElementById('addSaveBtn');
    const exitBtn = document.getElementById('exitBtn');
    const searchBtn = document.getElementById('searchBtn');
    const updateBtn = document.getElementById('updateBtn');
    const printBtn = document.getElementById('printBtn');
    const modal = document.getElementById('searchModal');
    const closeBtn = document.querySelector('.close');
    const searchSubmit = document.getElementById('searchSubmit');
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');

    // Sample data storage (in a real app, you'd use a database)
    let records = JSON.parse(localStorage.getItem('royaltyRecords')) || [];
    let currentEditingId = null;

    // Add/Save button click handler
    addSaveBtn.addEventListener('click', function() {
        if (form.checkValidity()) {
            const formData = {
                id: Date.now().toString(),
                srNo: document.getElementById('srNo').value,
                date: document.getElementById('date').value,
                royaltyNo: document.getElementById('royaltyNo').value,
                pageNo: document.getElementById('pageNo').value,
                vehicleNo: document.getElementById('vehicleNo').value,
                ton: document.getElementById('ton').value,
                paymentType: document.querySelector('input[name="paymentType"]:checked').value,
                amount: document.getElementById('amount').value,
                supplierParty: document.getElementById('supplierParty').value,
                creditParty: document.getElementById('creditParty').value
            };

            if (currentEditingId) {
                // Update existing record
                const index = records.findIndex(r => r.id === currentEditingId);
                if (index !== -1) {
                    records[index] = formData;
                    alert('Record updated successfully!');
                }
                currentEditingId = null;
                addSaveBtn.innerHTML = '<i class="fas fa-save"></i> Add/Save';
            } else {
                // Add new record
                records.push(formData);
                alert('Record added successfully!');
            }

            // Save to localStorage
            localStorage.setItem('royaltyRecords', JSON.stringify(records));
            
            // Reset form
            form.reset();
        } else {
            alert('Please fill all required fields!');
        }
    });

    // Exit button click handler
    exitBtn.addEventListener('click', function() {
        if (confirm('Are you sure you want to exit?')) {
            // In a real app, you might redirect or close the window
            console.log('Exit clicked');
        }
    });

    // Search button click handler
    searchBtn.addEventListener('click', function() {
        modal.style.display = 'block';
    });

    // Close modal
    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    // Search submit handler
    searchSubmit.addEventListener('click', function() {
        const searchTerm = searchInput.value.toLowerCase();
        if (!searchTerm) {
            alert('Please enter a search term');
            return;
        }

        const results = records.filter(record => 
            record.srNo.toLowerCase().includes(searchTerm) || 
            record.vehicleNo.toLowerCase().includes(searchTerm)
        );

        displaySearchResults(results);
    });

    // Display search results
    function displaySearchResults(results) {
        if (results.length === 0) {
            searchResults.innerHTML = '<p>No records found</p>';
            return;
        }

        let html = '<div class="results-container">';
        results.forEach(record => {
            html += `
                <div class="result-item">
                    <p><strong>SR NO:</strong> ${record.srNo}</p>
                    <p><strong>Date:</strong> ${record.date}</p>
                    <p><strong>Vehicle No:</strong> ${record.vehicleNo}</p>
                    <p><strong>Amount:</strong> ₹${record.amount}</p>
                    <button class="btn btn-sm btn-primary edit-btn" data-id="${record.id}">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn btn-sm btn-danger delete-btn" data-id="${record.id}">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
                <hr>
            `;
        });
        html += '</div>';

        searchResults.innerHTML = html;

        // Add event listeners to edit and delete buttons
        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                editRecord(id);
            });
        });

        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                deleteRecord(id);
            });
        });
    }

    // Edit record
    function editRecord(id) {
        const record = records.find(r => r.id === id);
        if (record) {
            document.getElementById('srNo').value = record.srNo;
            document.getElementById('date').value = record.date;
            document.getElementById('royaltyNo').value = record.royaltyNo;
            document.getElementById('pageNo').value = record.pageNo;
            document.getElementById('vehicleNo').value = record.vehicleNo;
            document.getElementById('ton').value = record.ton;
            document.querySelector(`input[name="paymentType"][value="${record.paymentType}"]`).checked = true;
            document.getElementById('amount').value = record.amount;
            document.getElementById('supplierParty').value = record.supplierParty;
            document.getElementById('creditParty').value = record.creditParty;
            
            currentEditingId = id;
            addSaveBtn.innerHTML = '<i class="fas fa-save"></i> Save Changes';
            modal.style.display = 'none';
        }
    }

    // Delete record
    function deleteRecord(id) {
        if (confirm('Are you sure you want to delete this record?')) {
            records = records.filter(r => r.id !== id);
            localStorage.setItem('royaltyRecords', JSON.stringify(records));
            displaySearchResults(records.filter(r => 
                r.srNo.toLowerCase().includes(searchInput.value.toLowerCase()) || 
                r.vehicleNo.toLowerCase().includes(searchInput.value.toLowerCase())
            ));
        }
    }

    // Update button click handler
    updateBtn.addEventListener('click', function() {
        if (records.length === 0) {
            alert('No records to update. Please add some records first.');
            return;
        }
        searchInput.value = '';
        modal.style.display = 'block';
        displaySearchResults(records);
    });

    // Print button click handler
    printBtn.addEventListener('click', function() {
        if (records.length === 0) {
            alert('No records to print. Please add some records first.');
            return;
        }
        
        // Create a printable table of all records
        let printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
                <head>
                    <title>Royalty Records Printout</title>
                    <style>
                        body { font-family: Arial, sans-serif; }
                        h1 { text-align: center; color: #2c3e50; }
                        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                        th { background-color: #f2f2f2; }
                        .print-date { text-align: right; margin-bottom: 20px; }
                    </style>
                </head>
                <body>
                    <h1>Royalty Records</h1>
                    <div class="print-date">Printed on: ${new Date().toLocaleString()}</div>
                    <table>
                        <thead>
                            <tr>
                                <th>SR NO</th>
                                <th>Date</th>
                                <th>Royalty No</th>
                                <th>Vehicle No</th>
                                <th>Ton</th>
                                <th>Payment</th>
                                <th>Amount</th>
                                <th>Supplier</th>
                                <th>Credit Party</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${records.map(record => `
                                <tr>
                                    <td>${record.srNo}</td>
                                    <td>${record.date}</td>
                                    <td>${record.royaltyNo}</td>
                                    <td>${record.vehicleNo}</td>
                                    <td>${record.ton}</td>
                                    <td>${record.paymentType}</td>
                                    <td>₹${record.amount}</td>
                                    <td>${record.supplierParty}</td>
                                    <td>${record.creditParty}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                </body>
            </html>
        `);
        printWindow.document.close();
        printWindow.print();
    });

    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    });
});// Print button click handler - updated for PDF generation
printBtn.addEventListener('click', function() {
    if (records.length === 0) {
        alert('No records to print. Please add some records first.');
        return;
    }
    
    // Ask user what format they want
    const format = prompt('Choose output format:\n1. Print Preview\n2. PDF Download\n3. Both', '1');
    
    if (format === null) return; // User cancelled
    
    // Generate the report content
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();
    
    // Add title
    doc.setFontSize(18);
    doc.text('Royalty Records Report', 105, 15, { align: 'center' });
    
    // Add print date
    doc.setFontSize(10);
    doc.text(`Generated on: ${new Date().toLocaleString()}`, 105, 22, { align: 'center' });
    
    // Prepare data for the table
    const headers = [
        'SR NO',
        'Date',
        'Royalty No',
        'Vehicle No',
        'Ton',
        'Payment',
        'Amount',
        'Supplier',
        'Credit Party'
    ];
    
    const data = records.map(record => [
        record.srNo,
        record.date,
        record.royaltyNo,
        record.vehicleNo,
        record.ton,
        record.paymentType,
        '₹' + record.amount,
        record.supplierParty,
        record.creditParty
    ]);
    
    // Add table to PDF
    doc.autoTable({
        head: [headers],
        body: data,
        startY: 30,
        styles: {
            fontSize: 8,
            cellPadding: 2,
            overflow: 'linebreak'
        },
        columnStyles: {
            0: { cellWidth: 'auto' },
            1: { cellWidth: 'auto' },
            2: { cellWidth: 'auto' },
            3: { cellWidth: 'auto' },
            4: { cellWidth: 'auto' },
            5: { cellWidth: 'auto' },
            6: { cellWidth: 'auto' },
            7: { cellWidth: 'auto' },
            8: { cellWidth: 'auto' }
        },
        margin: { top: 30 }
    });
    
    // Handle user's choice
    if (format === '1' || format === '3') {
        // Print Preview (using browser's print dialog)
        const printWindow = window.open('', '_blank');
        printWindow.document.write(`
            <html>
                <head>
                    <title>Royalty Records Print Preview</title>
                    <style>
                        body { font-family: Arial, sans-serif; margin: 20px; }
                        h1 { text-align: center; color: #2c3e50; }
                        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                        th { background-color: #f2f2f2; }
                        .print-date { text-align: right; margin-bottom: 20px; }
                        @media print {
                            body { margin: 0; padding: 10px; }
                            .no-print { display: none; }
                        }
                    </style>
                </head>
                <body>
                    <h1>Royalty Records</h1>
                    <div class="print-date">Printed on: ${new Date().toLocaleString()}</div>
                    <table>
                        <thead>
                            <tr>
                                ${headers.map(header => `<th>${header}</th>`).join('')}
                            </tr>
                        </thead>
                        <tbody>
                            ${data.map(row => `
                                <tr>
                                    ${row.map(cell => `<td>${cell}</td>`).join('')}
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    <button class="no-print" onclick="window.print()" style="margin-top: 20px; padding: 10px 15px; background: #4CAF50; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        Print Now
                    </button>
                    <button class="no-print" onclick="window.close()" style="margin-top: 20px; margin-left: 10px; padding: 10px 15px; background: #f44336; color: white; border: none; border-radius: 4px; cursor: pointer;">
                        Close
                    </button>
                </body>
            </html>
        `);
        printWindow.document.close();
    }
    
    if (format === '2' || format === '3') {
        // Save PDF
        const fileName = `Royalty_Records_${new Date().toISOString().slice(0, 10)}.pdf`;
        doc.save(fileName);
    }
});// WhatsApp button click handler
document.getElementById('whatsappBtn').addEventListener('click', function() {
    if (records.length === 0) {
        alert('No records to send. Please add some records first.');
        return;
    }

    // Ask user what format they want
    const format = prompt('Choose report format:\n1. Summary (text only)\n2. Detailed (CSV file)', '1');
    
    if (format === null) return; // User cancelled

    if (format === '1') {
        // Generate text summary
        let message = `*Royalty Records Report*\n\n`;
        message += `*Generated on:* ${new Date().toLocaleString()}\n`;
        message += `*Total Records:* ${records.length}\n\n`;
        
        // Add summary of each record
        records.forEach((record, index) => {
            message += `*Record ${index + 1}:*\n`;
            message += `SR NO: ${record.srNo}\n`;
            message += `Date: ${record.date}\n`;
            message += `Vehicle No: ${record.vehicleNo}\n`;
            message += `Amount: ₹${record.amount}\n`;
            message += `Payment: ${record.paymentType}\n\n`;
        });

        // Encode for WhatsApp URL
        const encodedMessage = encodeURIComponent(message);
        window.open(`https://wa.me/?text=${encodedMessage}`, '_blank');
    } 
    else if (format === '2') {
        // Generate CSV file
        let csv = 'SR NO,DATE,ROYALTY NO,VEHICLE NO,TON,PAYMENT TYPE,AMOUNT,SUPPLIER PARTY,CREDIT PARTY\n';
        
        records.forEach(record => {
            csv += `"${record.srNo}","${record.date}","${record.royaltyNo}","${record.vehicleNo}","${record.ton}","${record.paymentType}","${record.amount}","${record.supplierParty}","${record.creditParty}"\n`;
        });

        // Create blob and download
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const fileName = `Royalty_Records_${new Date().toISOString().slice(0, 10)}.csv`;
        
        // Create temporary link and click it
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', fileName);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

        // Open WhatsApp after a short delay to allow download
        setTimeout(() => {
            const message = `Here's the detailed Royalty Records report I just generated (attached CSV file). Generated on ${new Date().toLocaleString()}`;
            const encodedMessage = encodeURIComponent(message);
            window.open(`https://wa.me/?text=${encodedMessage}`, '_blank');
        }, 1000);
    }
});// Generate Report button click handler
printBtn.addEventListener('click', function() {
    if (records.length === 0) {
        alert('No records to generate report. Please add some records first.');
        return;
    }

    generateReport();
});

function generateReport() {
    // Create new window for report
    const reportWindow = window.open('', '_blank');
    
    // Clone the report template
    const reportContent = document.getElementById('reportTemplate').cloneNode(true);
    reportContent.style.display = 'block';
    
    // Set report metadata
    reportContent.querySelector('#reportDate').textContent = new Date().toLocaleString();
    reportContent.querySelector('#recordCount').textContent = records.length;
    
    // Populate table data
    const tableBody = reportContent.querySelector('#reportData');
    records.forEach(record => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${record.srNo}</td>
            <td>${record.date}</td>
            <td>${record.royaltyNo}</td>
            <td>${record.vehicleNo}</td>
            <td>${record.ton}</td>
            <td>${record.paymentType}</td>
            <td>₹${record.amount}</td>
            <td>${record.supplierParty}</td>
            <td>${record.creditParty}</td>
        `;
        tableBody.appendChild(row);
    });
    
    // Write to the new window
    reportWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Royalty Records Report</title>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
            <style>
                ${document.querySelector('style').innerHTML}
            </style>
        </head>
        <body>
            ${reportContent.innerHTML}
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.25/jspdf.plugin.autotable.min.js"></script>
            <script>
                // Print Report button
                document.getElementById('printReportBtn').addEventListener('click', function() {
                    window.print();
                });
                
                // PDF Report button
                document.getElementById('pdfReportBtn').addEventListener('click', function() {
                    const { jsPDF } = window.jspdf;
                    const doc = new jsPDF();
                    
                    doc.setFontSize(18);
                    doc.text('Royalty Records Report', 105, 15, { align: 'center' });
                    
                    doc.setFontSize(10);
                    doc.text(\`Generated on: \${new Date().toLocaleString()}\`, 105, 22, { align: 'center' });
                    
                    const headers = [
                        'SR NO', 'Date', 'Royalty No', 'Vehicle No', 
                        'Ton', 'Payment', 'Amount', 'Supplier', 'Credit Party'
                    ];
                    
                    const data = [
                        ${records.map(record => 
                            `["${record.srNo}", "${record.date}", "${record.royaltyNo}", 
                            "${record.vehicleNo}", "${record.ton}", "${record.paymentType}", 
                            "₹${record.amount}", "${record.supplierParty}", "${record.creditParty}"]`
                        ).join(',\n')}
                    ];
                    
                    doc.autoTable({
                        head: [headers],
                        body: data,
                        startY: 30,
                        styles: { fontSize: 8, cellPadding: 2 }
                    });
                    
                    const fileName = \`Royalty_Records_\${new Date().toISOString().slice(0, 10)}.pdf\`;
                    doc.save(fileName);
                });
                
                // WhatsApp Report button
                document.getElementById('whatsappReportBtn').addEventListener('click', function() {
                    const format = prompt('Choose report format:\\n1. Summary (text only)\\n2. Detailed (CSV file)', '1');
                    
                    if (format === '1') {
                        let message = \`*Royalty Records Report*\\n\\n\`;
                        message += \`*Generated on:* \${new Date().toLocaleString()}\\n\`;
                        message += \`*Total Records:* \${${records.length}}\\n\\n\`;
                        
                        ${records.map((record, index) => 
                            `message += \`*Record \${${index} + 1}:*\\n\`;
                            message += \`SR NO: \${"${record.srNo}"}\\n\`;
                            message += \`Date: \${"${record.date}"}\\n\`;
                            message += \`Vehicle No: \${"${record.vehicleNo}"}\\n\`;
                            message += \`Amount: ₹\${"${record.amount}"}\\n\`;
                            message += \`Payment: \${"${record.paymentType}"}\\n\\n\`;`
                        ).join('\n')}
                        
                        const encodedMessage = encodeURIComponent(message);
                        window.open(\`https://wa.me/?text=\${encodedMessage}\`, '_blank');
                    } 
                    else if (format === '2') {
                        let csv = 'SR NO,DATE,ROYALTY NO,VEHICLE NO,TON,PAYMENT TYPE,AMOUNT,SUPPLIER PARTY,CREDIT PARTY\\n';
                        
                        ${records.map(record => 
                            `csv += \`"${record.srNo}","${record.date}","${record.royaltyNo}","${record.vehicleNo}",` +
                            `"${record.ton}","${record.paymentType}","${record.amount}",` +
                            `"${record.supplierParty}","${record.creditParty}"\\n\`;`
                        ).join('')}
                        
                        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
                        const url = URL.createObjectURL(blob);
                        const fileName = \`Royalty_Records_\${new Date().toISOString().slice(0, 10)}.csv\`;
                        
                        const link = document.createElement('a');
                        link.setAttribute('href', url);
                        link.setAttribute('download', fileName);
                        link.style.visibility = 'hidden';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        
                        setTimeout(() => {
                            const message = \`Here's the detailed Royalty Records report I just generated (attached CSV file). Generated on \${new Date().toLocaleString()}\`;
                            const encodedMessage = encodeURIComponent(message);
                            window.open(\`https://wa.me/?text=\${encodedMessage}\`, '_blank');
                        }, 1000);
                    }
                });
                
                // Close Report button
                document.getElementById('closeReportBtn').addEventListener('click', function() {
                    window.close();
                });
            </script>
        </body>
        </html>
    `);
    reportWindow.document.close();
}